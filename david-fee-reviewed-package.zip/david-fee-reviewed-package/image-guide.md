# Image guide for the reviewed DAVID article

All listed graphics include a full-resolution PNG and an editable SVG in
`images/`. Each SVG embeds the supplied Rayls mark unchanged, including its black
background. No account watermark or capture date is added. Block references
remain because they identify the scope of the evidence.

## Preferred revised article set

| Asset stem | Size | Recommended location | What it communicates |
|---|---|---|---|
| `david-fee-banner-2000x800` | 2000 × 800 | Article cover | A gas payment is not, by itself, proof of a final token burn |
| `david-table-01-gas-fee-reconciliation` | 2000 × 1125 | After the two-row table in “Where did the sampled gas payments actually go?” | Exact total, Aggregator and author amounts for the two highlighted transactions |
| `david-table-02-recorded-usdr-balances` | 2000 × 1125 | After the two recorded-balance rows in “Was the next step ready to execute?” | The two primary balances and their block references; both are below the nominal minimum |
| `david-table-03-read-only-swap-tests` | 2000 × 1125 | After the five-row simulation table in “What did read-only execution reveal?” | The five standard swap-case outcomes at both captured blocks |

The third table does not show the separate funded-override or empty-distribution
tests. Keep those two results in the article text and evidence package. Avoid a
caption claiming that the table covers every simulation in the investigation.

The balance and simulation tables use the primary October 5/7 observations.
They do not substitute the supplementary October 9 state for the published
numbers. Keep exact values in the article text as well, so readers can copy and
check them without extracting lettering from an image.

## Earlier explanatory alternatives

| Asset stem | Size | Suggested use |
|---|---|---|
| `david-fee-01-six-transactions-2000x1125` | 2000 × 1125 | After the sample-percentage explanation, when a comparison across all six transactions adds more than another table |
| `david-fee-02-swap-prerequisites-2000x1125` | 2000 × 1125 | After the counterfactual pool-check explanation, when readers need the distinction between balance and pool prerequisites |

These are alternatives, not a requirement to publish every included graphic.
The article can use the cover plus the three tables. Add or substitute an
explanatory figure only where it adds a distinct part of the argument.

## Preview and QA files

- The earlier three figures retain their `-mobile-preview.png` files, rendered at
  500 pixels wide, and their `-text-audit.json` text-bound records.
- The new three tables include `-700px.png` previews and `-text.json` text bounds.
- `image-dimensions.json` lists all six full-resolution assets and text counts.
- `table-qa.json` contains the new tables' text-bound audit and logo identity.

Use the full-resolution PNG for publication. The previews are for checking
legibility, not for upload. Inspect every word at 100% zoom. Keep the lower-right
clear area of the new tables free of added evidence text so a platform watermark
does not cover a number or conclusion.

All diagrams and numeric tables are SVG-derived layouts. They do not depict a
completed onchain execution that the observations have not established.
