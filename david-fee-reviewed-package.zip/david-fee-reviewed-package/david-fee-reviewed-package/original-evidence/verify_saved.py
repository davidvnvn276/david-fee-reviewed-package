#!/usr/bin/env python3
"""Offline arithmetic and bytecode checks on the original recorded responses.

This verifies internal consistency of saved evidence. It does not authenticate
an RPC provider or reconstruct the chain's consensus certificate.
"""
import json
from decimal import Decimal
from pathlib import Path

P = Path(__file__).resolve().parent / 'raw'
def read(name):
    return json.loads((P / (name + '.json')).read_text())
def label(names_file, values_file):
    names = read(names_file)
    return {names[x['id'] - 1]: x for x in read(values_file)}
def integer(x):
    if 'error' in x or x.get('result') is None:
        raise ValueError('Unavailable data must not be treated as zero')
    return int(x['result'], 16)
def words(x):
    s = x['result'][2:]
    return [int(s[n:n+64], 16) for n in range(0, len(s), 64)]

by = label('historical-and-fee-names', 'historical-and-fee-results')
authors = label('author-balance-names', 'author-balance-result')
for n in [11847978, 11848013, 11848024]:
    block = by['fee_' + str(n) + '_block']['result']
    assert len(block['transactions']) == 1
    tx = block['transactions'][0]
    receipt = by['receipt_' + tx['hash']]['result']
    assert receipt['status'] == '0x1'
    assert receipt['blockHash'] == block['hash']
    assert int(receipt['blockNumber'], 16) == n
    gas = int(receipt['gasUsed'], 16)
    assert gas == int(block['gasUsed'], 16)
    price = int(receipt['effectiveGasPrice'], 16)
    base = int(block['baseFeePerGas'], 16)
    collector = integer(by['fee_' + str(n) + '_after']) - integer(by['fee_' + str(n) + '_before'])
    author = integer(authors[str(n) + '_after']) - integer(authors[str(n) + '_before'])
    assert collector == gas * base
    assert author == gas * (price - base)
    assert collector + author == gas * price
    print('PASS', n, 'base-fee credit and author credit reconcile exactly')

state = {x['id']: x for x in read('snapshot-calls')}
assert integer(state[20]) == words(state[18])[0] == 691782528048000000000
assert words(state[1]) == [5000, 0, 5000]
assert words(state[2]) == [0, 0, 0, 0]
assert words(state[3]) == [0, 0]
assert words(state[4]) == [1000000000, 100000000000]
assert words(state[15]) == [0, 0]
assert words(state[16]) == [0]
assert words(state[19]) == [18]
assert words(state[13]) == [0]
print('PASS block 11848988 state and the two USDr balance views')

sims = label('simulation-names', 'simulation-result')
expected = {'zero': '0x1f2a2005', 'ten': '0xafa4a09a',
            'minimum': '0xf4d678b8', 'over_maximum': '0xfc7892ce',
            'unauthorized_minimum': '0xe2517d3f', 'funded_override': '0xd64e375e'}
for name, selector in expected.items():
    assert sims[name]['error']['code'] == 3
    assert sims[name]['error']['data'].startswith(selector)
assert integer(sims['empty_distribution']) == 0
assert integer(sims['keeper_role_confirmed']) == 1
assert sims['implementation_code']['result'].lower() == read('aggregator-impl')['deployed_bytecode'].lower()
assert ('0x' + sims['implementation_slot']['result'][-40:]).lower() == '0x07e17e17e17e17e17e17e17e17e17e17e17e17e4'
print('PASS six revert checks, empty distribution, keeper role and runtime bytecode comparison')

for n in [5000000, 8000000, 10000000]:
    assert 'error' in by['historical_' + str(n) + '_balance']
print('Recorded pruned-state errors remain errors, not zero balances.')
print('Original-capture checks passed.')

# Later capture: verify all three additional fees from the stored RPC values,
# not from the plotted percentages or calculated CSV alone.
ROOT=P.parent
new=ROOT/'repeat-fees-20261007'
def labeled_folder(folder, stem):
    labels=json.loads((folder/(stem+'-labels.json')).read_text())
    result=json.loads((folder/(stem+'-response.json')).read_text())
    return {labels[x['id']-1]:x for x in result}
new_blocks=labeled_folder(new,'01')
new_authors=labeled_folder(new,'02')
new_queries=json.loads((new/'02-request.json').read_text())
new_names=json.loads((new/'02-labels.json').read_text())
author_queries=dict(zip(new_names,new_queries))
facts=json.loads((ROOT/'facts.json').read_text())
for row in facts['fees']:
    n=row['block']
    if n < 12000000:
        continue
    k=str(n); block=new_blocks[k+'_block']['result']; receipt=new_blocks[k+'_receipt']['result']
    assert len(block['transactions'])==1
    assert receipt['status']=='0x1'
    assert receipt['transactionHash']==block['transactions'][0]['hash']==row['tx_hash']
    assert receipt['blockHash']==block['hash']==row['block_hash']
    assert int(receipt['blockNumber'],16)==n
    gas=int(receipt['gasUsed'],16); base=int(block['baseFeePerGas'],16); effective=int(receipt['effectiveGasPrice'],16)
    assert gas==int(block['gasUsed'],16)==row['gas_used']
    collector=integer(new_blocks[k+'_collector_after'])-integer(new_blocks[k+'_collector_before'])
    author=integer(new_authors[k+'_author_after'])-integer(new_authors[k+'_author_before'])
    assert author_queries[k+'_author_before']['params'][0].lower()==block['miner'].lower()
    assert author_queries[k+'_author_after']['params'][0].lower()==block['miner'].lower()
    assert collector==gas*base==int(row['collector_delta_raw'])
    assert author==gas*(effective-base)==int(row['author_delta_raw'])
    assert collector+author==gas*effective==int(row['receipt_fee_raw'])
    assert Decimal(row['aggregator_share_percent'])==Decimal(100)*Decimal(collector)/Decimal(gas*effective)
    print('PASS',n,'new base/priority credits and derived share')

folder=ROOT/'repeat-state-20261007'
latest=labeled_folder(folder,'02'); sims=labeled_folder(folder,'03')
summary=json.loads((folder/'summary.json').read_text())
block=json.loads((folder/'block.json').read_text())
assert int(block['number'],16)==summary['block']==12018889
assert block['hash']==summary['block_hash']
assert integer(latest['native_USDr_balance'])==words(latest['USDr_balanceOf'])[0]==int(summary['native_usdr_raw'])==697144028784000000000
assert words(latest['getConfig'])==summary['config_basis_points']==[5000,0,5000]
assert words(latest['getStats'])==[0,0]
assert words(latest['getSwapLimits'])==[1000000000,100000000000]
assert words(latest['getPoolConfig'])==[0,0]
assert words(latest['getPendingDistribution'])==[0,0,0,0]
assert ('0x'+latest['implementation_slot']['result'][-40:]).lower()=='0x07e17e17e17e17e17e17e17e17e17e17e17e17e4'
meta=json.loads((folder/'explorer-implementation.json').read_text())
assert latest['implementation_code']['result'].lower()==meta['deployed_bytecode'].lower()
assert integer(sims['keeper_role_confirmed'])==1
for name,selector in expected.items():
    assert sims[name]['error']['code']==3
    assert sims[name]['error']['data'].startswith(selector)
assert integer(sims['empty_distribution'])==0
print('PASS block 12018889 state, implementation and all seven simulation outcomes')

# Preserve the failed later attempts as unavailable historical data.
unavailable=ROOT/'historical-recheck-20261007'
labels=json.loads((unavailable/'labels.json').read_text())
responses=json.loads((unavailable/'response.json').read_text())
for response in responses:
    label=labels[response['id']-1]
    if label.endswith('_before') or label.endswith('_after'):
        assert 'error' in response
print('PASS October 7 pruning responses are errors, never zero balances')
print('All six fee reconciliations and captured state/simulation checks passed.')
