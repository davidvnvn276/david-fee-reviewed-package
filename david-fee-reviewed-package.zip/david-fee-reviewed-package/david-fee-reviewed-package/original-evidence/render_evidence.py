from pathlib import Path
from datetime import datetime
from decimal import Decimal
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT=Path(__file__).resolve().parent
facts=json.loads((ROOT/'facts.json').read_text())
latest=facts['october_7_snapshot']
NAVY='#14263D'; MUTED='#536478'; BASE='#6654B5'; TIP='#D6AB34'; BG='#F6F7FA'; BORDER='#DDE3EB'; GREEN='#276C54'; RED='#A53D2F'
plt.rcParams.update({'font.family':'DejaVu Sans','text.color':NAVY,'axes.labelcolor':MUTED,'font.size':14})

fig=plt.figure(figsize=(16,10.4),dpi=125,facecolor=BG)
fig.text(.045,.95,'DAVID · Rayls Public Chain · measured fee allocation',fontsize=14,color=MUTED)
fig.text(.045,.885,'The Aggregator received different shares of total gas fees',fontsize=25,weight='bold')
fig.text(.045,.836,'Six selected single-transaction blocks. Twelve balance changes reconciled exactly.',fontsize=16,color=MUTED)
ax=fig.add_axes([.29,.265,.655,.48],facecolor=BG)
ax.set_xlim(0,100); ax.set_ylim(-.55,5.55)
ax.spines[['top','left','right']].set_visible(False); ax.spines['bottom'].set_color(BORDER)
ax.set_xticks([0,25,50,75,100]); ax.set_xticklabels(['0%','25%','50%','75%','100%'])
ax.grid(axis='x',color=BORDER,linewidth=.8,zorder=0); ax.set_axisbelow(True)
ax.set_xlabel('Share of the transaction’s total USDr gas fee',fontsize=14,labelpad=15)
ax.set_yticks([]); ax.tick_params(axis='x',labelsize=13,colors=MUTED)
rows=sorted(facts['fees'],key=lambda r:r['block'])
for idx,row in enumerate(rows):
    y=5-idx
    base=float(Decimal(row['aggregator_share_percent'])); tip=100-base
    ax.barh(y,base,height=.48,color=BASE,zorder=3)
    ax.barh(y,tip,left=base,height=.48,color=TIP,zorder=3)
    ax.text(base/2,y,f'{base:.2f}%',ha='center',va='center',fontsize=16,color='white',weight='bold')
    ax.text(base+tip/2,y,f'{tip:.2f}%',ha='center',va='center',fontsize=16,color=NAVY,weight='bold')
    day=datetime.fromisoformat(row['timestamp_utc']).strftime('%-d Oct 2026')
    ax.text(-4,y+.12,'Block '+format(row['block'],','),ha='right',va='center',fontsize=15,weight='bold')
    ax.text(-4,y-.18,day,ha='right',va='center',fontsize=12,color=MUTED)
fig.text(.29,.783,'■  Base-fee credit → Aggregator',fontsize=15,color=BASE,weight='bold')
fig.text(.64,.783,'■  Priority-fee credit → block author',fontsize=15,color='#8A6811',weight='bold')
fig.text(.045,.159,'Measured share = Aggregator balance increase ÷ receipt gas fee',fontsize=18,color=GREEN,weight='bold')
fig.text(.045,.113,'83.33% and 16.15% are sample results, not network-wide averages or permanent split rules.',fontsize=14,color=MUTED)
fig.text(.045,.054,'5 Oct: one account’s claim / approval / delegation. 7 Oct: three setPrice calls from a second account.',fontsize=13,color=MUTED)
fig.savefig(ROOT/'david-rayls-fee-split.png',dpi=125,facecolor=BG)
plt.close(fig)

fig=plt.figure(figsize=(16,10),dpi=125,facecolor=BG)
fig.text(.045,.95,'DAVID · pinned configuration and read-only simulations',fontsize=14,color=MUTED)
fig.text(.045,.884,'Sufficient balance alone did not clear the swap route',fontsize=27,weight='bold')
fig.text(.045,.835,'Rayls mainnet · Block 12,018,889 · 7 Oct 2026, 07:47:08 UTC',fontsize=16,color=MUTED)
def panel(x,y,w,h):
    fig.add_artist(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.01,rounding_size=.012',facecolor='white',edgecolor=BORDER,linewidth=1,transform=fig.transFigure,zorder=0))
panel(.045,.465,.42,.285); panel(.51,.465,.44,.285)
fig.text(.069,.708,'Actual state at the pinned block',fontsize=16,color=MUTED)
fig.text(.069,.635,latest['usdr_balance']+' USDr',fontsize=25,weight='bold')
fig.text(.069,.580,'Minimum swap: 1,000 USDr',fontsize=17,color=RED,weight='bold')
fig.text(.069,.511,'1,000-USDr eth_call → InsufficientBalance',fontsize=14,color=RED)
fig.text(.534,.708,'Counterfactual eth_call only',fontsize=16,color='#8A6811')
fig.text(.534,.635,'2,000 USDr simulated balance',fontsize=23,weight='bold')
fig.text(.534,.580,'No deposit or persistent state change',fontsize=15,color=MUTED)
fig.text(.534,.511,'1,000-USDr attempt → PoolNotConfigured',fontsize=15,color=RED,weight='bold')
panel(.045,.244,.905,.143)
fig.text(.069,.351,'Captured configuration: 50% validators / 0% ecosystem / 50% burn',fontsize=17,weight='bold')
fig.text(.069,.288,'USDr pool: zero address    |    Recorded swaps: 0    |    RLS distributed: 0',fontsize=16,color=MUTED)
fig.text(.045,.169,'Repeated from 5 Oct: 691.782528048 USDr, with the same two simulated gate outcomes.',fontsize=14,color=MUTED)
fig.text(.045,.112,'The configuration and simulations do not demonstrate a completed token burn.',fontsize=18,color=RED,weight='bold')
fig.text(.045,.055,'One Public Chain proxy at two captured blocks. Other Rayls routes and historical burns are outside this test.',fontsize=13,color=MUTED)
fig.savefig(ROOT/'david-rayls-fee-gates.png',dpi=125,facecolor=BG)
plt.close(fig)
print('Rendered all six observations and the October 7 gate snapshot.')
