# Review report: DAVID's Rayls fee investigation

## Conclusion and scope

The article's six-sample calculations and its two primary configuration captures
are consistent with the preserved responses and the inspected implementation.
The saved reviewer rechecks corroborate the second main capture and the newer
fee samples. The evidence supports a narrow conclusion: paying gas, collecting
USDr, acquiring RLS, allocating a burn share, delivering it across chains and
destroying canonical Ethereum tokens are different stages.

This report reviews a saved investigation. It does not claim that a new live
mainnet check was performed when this English package was assembled. The
manuscript's primary snapshots remain October 5 and October 7. A previously
captured October 9 observation is included separately as supplementary evidence.

The material contains substantial original empirical work, but no review can
guarantee a quest score. Its strength is the combination of exact state
reconciliation, implementation inspection, repeat captures and boundary tests.
Its limits must remain visible alongside those findings.

## Claim-by-claim review

| Claim | Supporting evidence | Boundary |
|---|---|---|
| Rayls gas uses USDr, while the documented conversion and distribution route uses RLS | Network reference, tokenomics documentation and inspected implementation | Documentation alone does not establish that a conversion or burn executed |
| Base fees enter the Aggregator; priority fees credit the block author | Axyl specification and twelve exact saved balance differences | The collected share of total gas is not a fixed 50% or a network-wide average |
| Six selected blocks contain one transaction each | Preserved block headers and receipts | Later October 5 receipt queries returned null; the original receipts remain preserved |
| All twelve Aggregator/author balance differences reconcile exactly | Raw integer balances, receipt gas used, base fee and effective gas price | The October 5 balance states were later pruned on the public endpoint |
| The two sample groups have 83.33% and 16.15% Aggregator shares | Base fee divided by each sampled effective gas price | These rounded percentages describe the selected observations, not method-specific or permanent rates |
| The two example rows preserve the exact USDr values | `fee-reconciliation.csv`, `facts.json` and receipt/balance responses | Explorer labels identify displayed methods; account controllers are not inferred |
| Recorded balances are 691.782528048 and 697.144028784 USDr | Main captures at 11,848,988 and 12,018,889 | The latter was repeated at the same block; the former relies on saved state responses |
| The analysis uses the deployed proxy implementation | Chain ID, EIP-1967 slot and runtime bytes matched to Explorer | This is not a complete proxy upgrade history or independent consensus authentication |
| Native USDr balance and ERC-20 `balanceOf` agree | Both main captures and the documented USDr precompile interface | Agreement concerns the recorded address and block |
| Allocation is 5,000 / 0 / 5,000 basis points | `getConfig()` at both primary captures | The configuration can change; the percentage is not proof of execution |
| Nominal swap limits are 1,000 to 100,000 USDr | `getSwapLimits()` and the implementation's six-decimal normalization | Normalization truncates finer precision; use “nominal limits,” not an exact fractional upper-bound claim |
| The USDr pool, swap counter and distribution buckets are zero | Pinned state reads in the main captures | Zero state in this proxy is not proof of no burn anywhere in the ecosystem |
| Five standard swap tests return the reported errors | ABI-derived calldata, role check and saved `eth_call` results | A simulated authorized caller does not prove possession of its key |
| A simulated 2,000-USDr balance still reaches `PoolNotConfigured` | Explicit balance override plus a simulated 1,000-USDr swap | No deposit occurred and no persistent state changed |
| Empty distribution returns 0 | Saved `distributeEpochFees()` simulations | This is a simulated return, not a completed distribution transaction |
| Swap and distribution are separate keeper functions | Verified implementation source | Distribution consumes pending RLS; it is not itself a USDr-to-RLS swap |
| The evidence does not establish a final Ethereum burn | No connected successful swap, delivery and canonical burn transaction is established | This is not a claim that no historical RLS burn has occurred |

## Exact fee reconciliation

The first group consists of a reward claim, an approval and a delegation from one
account on October 5 at blocks 11,847,978; 11,848,013; and 11,848,024. The second
group consists of three Explorer-labelled `setPrice` calls from another account
on October 7 at blocks 12,018,215; 12,018,442; and 12,018,680. No identity or role is
assigned to either account beyond what the saved observations establish.

Each sampled block contains one transaction. The comparisons use the parent
block and the transaction block:

- Aggregator increase = gas used × block base fee.
- Author increase = gas used × (effective gas price − block base fee).
- Sum of both increases = gas used × effective gas price.

All twelve deltas match those integer calculations. Both groups use a base fee
of 48,000,000,000 native units per gas. The first group's effective gas price is
57,600,000,000; the second group's is 297,203,348,275. USDr uses 18 decimals.

| Example | Gas used | Total fee, USDr | Aggregator credit, USDr | Author credit, USDr |
|---|---:|---:|---:|---:|
| Approval at 11,848,013 | 51,378 | 0.0029593728 | 0.002466144 | 0.0004932288 |
| `setPrice` at 12,018,215 | 38,001 | 0.011294024437798275 | 0.001824048 | 0.009469976437798275 |

The approximately 83.33% and 16.15% shares follow the sampled gas prices. They do
not show that the transaction's method causes the split. The documented 50%
burn allocation applies to RLS obtained later, not to an already completed burn
of half of each user's total USDr gas payment.

## Primary configuration and gate tests

Chain ID: **72957**. Inspected proxy:
`0x07e17e17e17e17e17e17e17e17e17e17e17e17e3`.

| Capture | Block | Recorded USDr balance |
|---|---:|---:|
| October 5, 2026, 10:43:21 UTC | 11,848,988 | 691.782528048 |
| October 7, 2026, 07:47:08 UTC | 12,018,889 | 697.144028784 |

Both captures show the same allocation, nominal limits, zero USDr pool, zero
swap/distribution counters and empty pending buckets. Native and ERC-20 balance
reads agree. The runtime bytes match Explorer's published implementation bytes.
Both recorded balances are below the nominal 1,000-USDr minimum.

| Simulated case | Result at both primary blocks |
|---|---|
| Swap 0 USDr | `ZeroAmount` |
| Swap 10 USDr | `BelowMinimumSwap` |
| Swap 1,000 USDr | `InsufficientBalance` |
| Swap 100,001 USDr | `ExceedsMaximumSwap` |
| Swap 1,000 USDr from a caller without the keeper role | `AccessControlUnauthorizedAccount` |
| Distribute with empty pending RLS buckets | Return `0` |
| Override the balance to 2,000 USDr, then simulate a 1,000-USDr swap | `PoolNotConfigured` |

The counterfactual test isolates a subsequent gate. It cannot establish that a
funded swap would succeed, nor does it demonstrate a deposit. The implementation
sequence checks access and pause status, then the amount, supported token,
normalized limits and available balance before the pool-dependent swap.

## Saved reviewer corroboration

The reviewer preserved a separate same-block read at **12,018,889**. Its block
hash, configuration, balances, runtime bytes and all seven simulation outcomes
match the investigation's repeat capture. The reviewer also captured fresh block
**12,020,199**, timestamp **October 7, 2026, 08:16:09 UTC**: its USDr balance was
**697.171389504**, with the same recorded gates.

A separate HTTP batch asked for all six headers, all six receipts and 24
before/after balances. It produced 21 available and 15 unavailable observations:
all six headers matched, and the October 7 receipts and balance deltas were
available and matched. The October 5 receipt results were null; their balance
states were pruned. Those unavailable records remain visible in the package.

The delivered offline audit replays that batch; it does not fetch a new batch on
every run. Its 253 assertions include exact arithmetic, selectors, request/response
bindings, inner file hashes and comparison of the saved captures. The archived
earlier audit records 252 assertions. The additional check in this edition binds
the preserved HTTP batch to its reconstructed queries and response IDs.

Different reviewer captures of the same provider are corroborating RPC
observations. They do not independently authenticate an Axyl consensus
certificate or remove reliance on the provider and Explorer.

## Supplementary October 9 capture

`verification/supplementary-20261009/` contains a previously recorded read at
block **12,167,402**, timestamp **October 9, 2026, 14:34:00 UTC**, captured at
**14:34:25.323346 UTC**. It records **704.728012176 USDr**, equal native/ERC-20
balances, allocation 5,000 / 0 / 5,000, the same normalized limits, zero pool,
empty pending buckets, zero recorded counters and the same seven simulated
outcomes. The runtime SHA-256 is
`9e992038bbc77e73a6bac80d90ac9b839c7d73d3f0cb83e638951f90d31515b3`.

This is a third captured point, not proof of continuous conditions. It is kept
separate so it cannot silently change the article's published October 5/7 data.
The two main audit scripts do not claim to validate this supplementary capture;
its raw files are covered by the package inventory and remain available for
additional inspection.

## Editorial and reproduction decisions

- The current article uses nominal-limit terminology and distinguishes receipts
  that later returned null from balance state that was pruned.
- Its reproduction section links to the real public evidence repository and
  uses commands that work from the package root.
- The corrected claim CSV covers all six samples. The earlier claim map is
  preserved as an investigation artifact and is not the preferred review index.
- `image-guide.md` explains where the cover and three new data tables support the
  argument; earlier explanatory graphics remain available as alternatives.
- The English edition changes explanatory material and rebuilds the manifests.
  Raw RPC observations, source bytes and simulation calldata are preserved.
- The reviewer audit writes newly generated output outside the sealed package.

For a further investigation, the information gain would come from tracing an
actually executed conversion and distribution through its bridge delivery and
canonical Ethereum burn, or from recording a later change in the configuration.
Neither outcome is established by this package. More repeated arithmetic checks
alone would not create that missing transaction-level evidence.

## Sources and limits

- [Rayls Public Chain tokenomics](https://docs.rayls.com/docs/public-chain-tokenomics)
- [Axyl technical specification](https://docs.rayls.com/docs/about-the-axyl-consensus-algorithm)
- [Rayls Public Chain reference](https://docs.rayls.com/docs/public-chain-reference)
- [Fees Aggregator proxy](https://explorer.rayls.com/address/0x07e17e17e17e17e17e17e17e17e17e17e17e17e3)
- [Verified implementation](https://explorer.rayls.com/address/0x07e17e17e17e17e17e17e17e17e17e17e17e17e4?tab=contract)
- RPC endpoint recorded in the evidence: `https://mainnet-rpc.rayls.com/`.

These links identify the investigation's sources. The preserved bytes establish
what was reviewed; this localization is not a fresh verification of every linked
page. No wallet transaction, successful swap, completed distribution, Ethereum
delivery, canonical burn or consensus-certificate authentication is claimed.
