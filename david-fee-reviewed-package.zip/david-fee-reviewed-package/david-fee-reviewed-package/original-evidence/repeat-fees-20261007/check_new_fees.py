#!/usr/bin/env python3
import datetime, json, urllib.request
from decimal import Decimal
from pathlib import Path
P=Path(__file__).resolve().parent
O=P/('fee-recheck-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
O.mkdir(exist_ok=False)
RPC='https://mainnet-rpc.rayls.com/'
PROXY='0x07e17e17e17e17e17e17e17e17e17e17e17e17e3'
selected=[12018680,12018442,12018215]
items=json.loads((P/'explorer-transactions.json').read_text())['items']
labels={n:next(x for x in items if x['block_number']==n) for n in selected}
def batch(stem, named):
    q=[{'jsonrpc':'2.0','id':i,'method':method,'params':params} for i,(_,method,params) in enumerate(named,1)]
    (O/(stem+'-request.json')).write_text(json.dumps(q,indent=2))
    (O/(stem+'-labels.json')).write_text(json.dumps([v[0] for v in named],indent=2))
    req=urllib.request.Request(RPC,data=json.dumps(q).encode(),headers={'Content-Type':'application/json','User-Agent':'Mozilla/5.0','Origin':'https://dapp.rayls.com'})
    with urllib.request.urlopen(req,timeout=45) as r: a=json.loads(r.read())
    (O/(stem+'-response.json')).write_text(json.dumps(a,indent=2))
    by={x['id']:x for x in a}
    out={}
    for i,(name,_,_) in enumerate(named,1):
        if 'error' in by[i] or by[i].get('result') is None: raise RuntimeError(json.dumps(by[i]))
        out[name]=by[i]['result']
    return out
queries=[]
for n in selected:
    queries.extend([(str(n)+'_block','eth_getBlockByNumber',[hex(n),True]),
                    (str(n)+'_receipt','eth_getTransactionReceipt',[labels[n]['hash']]),
                    (str(n)+'_collector_before','eth_getBalance',[PROXY,hex(n-1)]),
                    (str(n)+'_collector_after','eth_getBalance',[PROXY,hex(n)])])
a=batch('01',queries)
queries=[]
for n in selected:
    b=a[str(n)+'_block']; assert len(b['transactions'])==1, 'Selected block is not single-transaction'
    r=a[str(n)+'_receipt']; assert r['status']=='0x1'; assert r['transactionHash']==b['transactions'][0]['hash']
    author=b['miner']
    assert b['transactions'][0]['from'].lower()!=author.lower()
    assert (b['transactions'][0].get('to') or '').lower()!=author.lower()
    queries.extend([(str(n)+'_author_before','eth_getBalance',[author,hex(n-1)]),
                    (str(n)+'_author_after','eth_getBalance',[author,hex(n)])])
z=batch('02',queries)
rows=[]
for n in selected:
    k=str(n); b=a[k+'_block']; r=a[k+'_receipt']; tx=b['transactions'][0]
    assert r['blockHash']==b['hash']; assert int(r['blockNumber'],16)==n
    gas=int(r['gasUsed'],16); assert gas==int(b['gasUsed'],16)
    base=int(b['baseFeePerGas'],16); effective=int(r['effectiveGasPrice'],16)
    collector=int(a[k+'_collector_after'],16)-int(a[k+'_collector_before'],16)
    author=int(z[k+'_author_after'],16)-int(z[k+'_author_before'],16)
    assert collector==gas*base; assert author==gas*(effective-base)
    assert collector+author==gas*effective
    d=lambda v: format(Decimal(v)/Decimal(10**18),'f')
    row={'block':n,'block_hash':b['hash'],'timestamp_utc':datetime.datetime.fromtimestamp(int(b['timestamp'],16),datetime.timezone.utc).isoformat(),
         'operation':'Explorer-labelled '+str(labels[n]['method']),'tx_hash':tx['hash'],'sender':tx['from'],
         'block_author':b['miner'],'transaction_count':1,'gas_used':gas,'base_fee_raw_per_gas':str(base),
         'effective_price_raw_per_gas':str(effective),'receipt_fee_raw':str(gas*effective),
         'collector_delta_raw':str(collector),'author_delta_raw':str(author),'receipt_fee_usdr':d(gas*effective),
         'collector_delta_usdr':d(collector),'author_delta_usdr':d(author),
         'aggregator_share_percent':str(Decimal(100)*Decimal(collector)/Decimal(gas*effective)),
         'base_credit_equal':True,'priority_credit_equal':True,'total_equal':True}
    rows.append(row)
    print(json.dumps(row),flush=True)
(O/'fees.json').write_text(json.dumps(rows,indent=2))
(O/'captured.json').write_text(json.dumps({'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rpc':RPC,'read_only':True},indent=2))
print('PASS three new one-transaction blocks, six exact balance reconciliations')
