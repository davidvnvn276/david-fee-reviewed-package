#!/usr/bin/env python3
"""Read-only Rayls fee investigation. Python 3, standard library only.

No wallet, private key, signing, transaction submission, or persistent state
change. --simulate adds eth_call tests; --override adds a counterfactual balance
override within eth_call only. Archive reads may be unavailable on a later date.
"""
import argparse
import datetime
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import urllib.request

HERE = Path(__file__).resolve().parent
RPC = 'https://mainnet-rpc.rayls.com/'
PROXY = '0x07e17e17e17e17e17e17e17e17e17e17e17e17e3'
IMPL = '0x07e17e17e17e17e17e17e17e17e17e17e17e17e4'
SLOT = '0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc'
ALLOWED = {'eth_chainId', 'eth_getBlockByNumber', 'eth_getBalance', 'eth_call',
           'eth_getCode', 'eth_getStorageAt', 'eth_getTransactionReceipt'}
DENOM = Decimal(10 ** 18)


def units(raw):
    return format(Decimal(int(raw)) / DENOM, 'f')


def words(raw):
    if not isinstance(raw, str) or not raw.startswith('0x'):
        raise ValueError('Missing RPC result; do not treat an RPC error as zero.')
    s = raw[2:]
    if len(s) % 64:
        raise ValueError('Unexpected ABI result length.')
    return [int(s[n:n + 64], 16) for n in range(0, len(s), 64)]


def get_json(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=35) as r:
        return json.loads(r.read())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--block', default='latest', help='latest or decimal block number')
    parser.add_argument('--output', help='New output directory; existing data is never overwritten')
    parser.add_argument('--simulate', action='store_true', help='Read-only eth_call gate tests')
    parser.add_argument('--override', action='store_true', help='Also test a simulated 2,000-USDr balance')
    args = parser.parse_args()
    if args.override and not args.simulate:
        parser.error('--override requires --simulate')
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out = Path(args.output or HERE / ('recheck-' + stamp)).resolve()
    out.mkdir(parents=True, exist_ok=False)
    calls = json.loads((HERE / 'templates' / 'call-queries.json').read_text())
    tests = json.loads((HERE / 'templates' / 'simulation-queries.json').read_text())
    seq = 0

    def save(name, value):
        (out / (name + '.json')).write_text(json.dumps(value, indent=2), encoding='utf-8')

    def rpc_batch(named):
        nonlocal seq
        seq += 1
        q = []
        for idx, (name, method, params) in enumerate(named, 1):
            if method not in ALLOWED:
                raise ValueError('Method is outside this script\'s read-only allowlist')
            q.append({'jsonrpc': '2.0', 'id': idx, 'method': method, 'params': params})
        save(str(seq).zfill(2) + '-request', q)
        req = urllib.request.Request(RPC, data=json.dumps(q).encode(), headers={
            'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0',
            'Origin': 'https://dapp.rayls.com', 'Referer': 'https://dapp.rayls.com/'})
        with urllib.request.urlopen(req, timeout=45) as r:
            result = json.loads(r.read())
        save(str(seq).zfill(2) + '-response', result)
        save(str(seq).zfill(2) + '-labels', [x[0] for x in named])
        by = {x['id']: x for x in result}
        return {name: by[idx] for idx, (name, _, _) in enumerate(named, 1)}

    def required(item):
        if 'error' in item:
            raise RuntimeError(json.dumps(item['error']) + '; no conclusion was recorded from this error.')
        if item.get('result') is None:
            raise RuntimeError('RPC returned null; no conclusion was recorded.')
        return item['result']

    tag = args.block if args.block == 'latest' else hex(int(args.block))
    head = rpc_batch([('chainId', 'eth_chainId', []),
                      ('block', 'eth_getBlockByNumber', [tag, False])])
    if int(required(head['chainId']), 16) != 72957:
        raise RuntimeError('Wrong chain ID; stopped.')
    block = required(head['block'])
    tag = block['number']
    timestamp = datetime.datetime.fromtimestamp(int(block['timestamp'], 16), datetime.timezone.utc).isoformat()
    print('Rayls mainnet, chain ID 72957')
    print('Pinned block:', int(tag, 16), '|', timestamp, flush=True)
    save('block', block)
    meta = get_json('https://explorer.rayls.com/api/v2/smart-contracts/' + IMPL)
    save('explorer-implementation', meta)
    named = [(c['name'], 'eth_call', [{'to': c['to'], 'data': c['data']}, tag]) for c in calls]
    named.extend([('native_USDr_balance', 'eth_getBalance', [PROXY, tag]),
                  ('implementation_slot', 'eth_getStorageAt', [PROXY, SLOT, tag]),
                  ('implementation_code', 'eth_getCode', [IMPL, tag])])
    state = rpc_batch(named)
    impl_word = required(state['implementation_slot'])
    if ('0x' + impl_word[-40:]).lower() != IMPL:
        raise RuntimeError('Implementation has changed; revise the ABI/source before interpreting results.')
    code = required(state['implementation_code'])
    if code.lower() != meta.get('deployed_bytecode', '').lower():
        raise RuntimeError('RPC runtime code does not match Explorer metadata; stopped.')
    native = int(required(state['native_USDr_balance']), 16)
    erc = words(required(state['USDr_balanceOf']))[0]
    config = words(required(state['getConfig']))
    stats = words(required(state['getStats']))
    limits = words(required(state['getSwapLimits']))
    pending = words(required(state['getPendingDistribution']))
    pool = words(required(state['getPoolConfig']))
    summary = {'block': int(tag, 16), 'block_hash': block['hash'], 'timestamp': timestamp,
               'native_usdr_raw': str(native), 'erc20_usdr_raw': str(erc),
               'usdr_balance': units(native), 'usdr_views_equal': native == erc,
               'usdr_decimals': words(required(state['USDr_decimals']))[0],
               'config_basis_points': config, 'swap_count': stats[0],
               'distributed_rls_raw': str(stats[1]), 'limits_normalized_usd6': limits,
               'pool': '0x' + format(pool[0], '040x'),
               'pending_raw': [str(x) for x in pending],
               'runtime_bytecode_matches_explorer': True,
               'runtime_sha256': hashlib.sha256(bytes.fromhex(code[2:])).hexdigest()}
    print('USDr balance:', units(native), '| native/ERC-20 match:', native == erc)
    print('Configuration, basis points:', config)
    print('Swaps:', stats[0], '| distributed RLS raw:', stats[1])
    print('USDr swap limits:', Decimal(limits[0]) / Decimal(10**6), 'to', Decimal(limits[1]) / Decimal(10**6))
    print('Configured USDr pool:', summary['pool'])
    print('RPC runtime bytecode matches Explorer:', True, flush=True)
    if args.simulate:
        named = []
        for c in tests['cases']:
            if c.get('override') and not args.override:
                continue
            params = [c['call'], tag]
            if c.get('override'):
                params.append(c['override'])
            named.append((c['name'], 'eth_call', params))
        named.extend((c['name'], c['method'], c['params'] + [tag])
                     for c in tests['extra'] if c['name'] == 'keeper_role_confirmed')
        results = rpc_batch(named)
        keeper = int(required(results['keeper_role_confirmed']), 16) == 1
        if not keeper:
            raise RuntimeError('Simulated caller no longer has KEEPER_ROLE; do not interpret old expectations.')
        error_names = {e['selector']: e['name'] for e in json.loads((HERE / 'templates' / 'errors.json').read_text())}
        simulated = []
        for name, item in results.items():
            if name == 'keeper_role_confirmed':
                continue
            err = item.get('error')
            value = err.get('data', '') if err else item.get('result')
            outcome = error_names.get(value[:10], 'Unknown RPC error: ' + json.dumps(err)) if err else 'Return ' + str(int(value, 16))
            simulated.append({'case': name, 'outcome': outcome, 'raw': item,
                              'counterfactual_balance_override': name == 'funded_override'})
            print(('COUNTERFACTUAL, no deposit: ' if name == 'funded_override' else 'eth_call: ') + name + ' -> ' + outcome)
        summary['simulations'] = simulated
    save('summary', summary)
    save('capture', {'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                     'rpc': RPC, 'read_only': True})
    print('Saved fresh raw evidence to:', out)
    print('No wallet connected. No transaction signed or submitted. No persistent state changed.')


if __name__ == '__main__':
    main()
