# Reviewer verification files

`independent_audit.py` is an offline audit of the saved investigation and reviewer
captures. Run it from the package root after installing the pinned dependency:

```bash
python -m pip install -r verification/requirements-audit.txt
python verification/independent_audit.py
```

It checks integer fee calculations, ABI selectors, calldata, role/error inputs,
request and block bindings, the inner file inventory, the same-block repeat and
the preserved independent HTTP batch. It reports 253 program assertions for
this English edition. The archived earlier audit reports 252. These counts are
not counts of independent experiments.

The additional assertion binds the preserved HTTP batch's request list and
response IDs to the reconstructed requests. No new network request is made by
this script. A missing captured response causes an error instead of an implicit
network fallback. Newly generated output is written to an external temporary
directory, or to a new directory passed with `--output`.

## Captures

| Directory | What was recorded |
|---|---|
| `independent-comparison/` | Separate saved batch of six headers, six receipt requests and 24 historical balance requests; unavailable observations are retained |
| `independent-pinned-12018889/` | Same-block repeat of the article's October 7 primary capture |
| `fresh-independent/` | Fresh review capture at block 12,020,199 |
| `supplementary-20261009/` | Additional previously captured state and simulations at block 12,167,402; separate from the article's primary observations |

Files named `request.json`, `response.json` and `audit.json` in the capture
directories preserve the original reviewer records. Their timestamps and old
field names, including `live_rechecks`, describe that recorded run. Replaying
them now does not convert them into current live observations.

The supplementary October 9 files are covered by the package manifest, but the
two main audit scripts do not claim to audit that additional capture. Its own
README identifies its inputs, results and limitations.

For fresh state reads, use `original-evidence/reproduce.py` as documented in the
root README. Provider data availability can change. RPC/Explorer agreement and
offline consistency do not independently authenticate a consensus certificate
or establish a completed Ethereum burn.
