#!/usr/bin/env python3
"""Check both delivered SHA-256 inventories without network access.

Python standard library only. Hash equality establishes file identity, not
independent authentication of the onchain observations.
"""
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def verify_manifest(directory, manifest_name):
    directory = directory.resolve()
    manifest = directory / manifest_name
    if not manifest.is_file():
        raise ValueError("Missing manifest: " + str(manifest))
    names = set()
    for line_number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
        if not line:
            continue
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            raise ValueError("Invalid manifest line %s in %s" % (line_number, manifest_name))
        expected, name = match.groups()
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts or name in names:
            raise ValueError("Unsafe or duplicate manifest path: " + name)
        target = (directory / relative).resolve()
        try:
            target.relative_to(directory)
        except ValueError:
            raise ValueError("Manifest path leaves its directory: " + name)
        if not target.is_file():
            raise ValueError("Missing included file: " + name)
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError("SHA-256 mismatch: " + name)
        names.add(name)
    if not names:
        raise ValueError("Empty manifest: " + manifest_name)
    return names


def main():
    try:
        outer = verify_manifest(ROOT, "SHA256SUMS-reviewed.txt")
        inner = verify_manifest(ROOT / "original-evidence", "SHA256SUMS.txt")
        included = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()}
        unlisted = sorted(included - outer - {"SHA256SUMS-reviewed.txt"})
        print(json.dumps({
            "status": "PASS",
            "reviewed_manifest_entries": len(outer),
            "original_evidence_manifest_entries": len(inner),
            "unlisted_files": unlisted,
            "scope": "File identity only; no network request or consensus authentication.",
        }, indent=2))
        if unlisted:
            print("Additional files are not sealed by this manifest; generated recheck output may appear here.")
        return 0
    except (OSError, ValueError) as error:
        print("Package verification failed: " + str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
