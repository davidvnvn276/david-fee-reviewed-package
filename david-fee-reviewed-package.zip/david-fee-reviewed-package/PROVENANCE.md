# Provenance and English-edition changes

This edition was rebuilt from the complete previously reviewed ZIP, rather than
from the later shortened public copy. Its source ZIP SHA-256 is:

`f417036f7f8bddbc731ab1d09b9506fa70c9076d58ee45094d59637a819f8f5f`

The source archive contained 129 files. The machine-readable
`package-provenance.json` records source hashes, retained files, changed files
and document replacements. It does not independently authenticate node data.

## Preserved observations

All 78 original investigation files other than its README,
translated guide and regenerated manifest retain byte-identical content. This
includes RPC requests/responses, contract source, ABI metadata, calldata,
calculations, the original English manuscript, scripts and investigation
graphics. Existing reviewer capture files also retain their original bytes.

## Changes

- The two explanatory documents previously written in Vietnamese have been
  replaced by `review-report.md` and `original-evidence/david-fee-guide.md`,
  both in English. Their substantive evidence limitations remain explicit.
- The root and inner READMEs explain the current files and reproduction
  commands. The reviewed manuscript links to the public evidence repository.
- Three updated DAVID data tables, their editable SVGs, previews and text QA
  have been added. The earlier cover and explanatory figures are retained.
- The previously captured October 9 files are included as supplementary
  observations; they do not change the primary October 5/7 article data.
- The reviewer audit is explicitly offline and writes generated outputs to a
  separate directory. It adds one request/response binding assertion.
- `verify_package.py` checks the two delivered SHA-256 inventories. Both
  inventories were regenerated because translated documents have new names
  and hashes. The original 80-entry inventory size is retained; its exact
  text and translated-document hash are not claimed unchanged.

## Captures and execution

The original observations, earlier reviewer checks and October 9 capture
were recorded before this localization. Running the delivered offline audit
does not produce fresh onchain observations. The fresh reproduction script
can obtain new read-only state, which may differ from the article.

No transaction submission, successful swap, final Ethereum burn or
independent consensus-certificate authentication is established by this
packaging work. The repository replacement is not claimed to be uploaded.

## Expanded reviewer-guide edition

The root README now provides setup, separate offline and live routes, expected
outputs, claim-to-file mappings, manual arithmetic, troubleshooting and scope
limits. The optional `requests/reviewer-pinned-state-request.json` input contains
twelve read-only calls at block 12,018,889, built from the preserved calldata.
The original observations, scripts, images and reviewer capture files were not
changed by this documentation expansion. The outer manifest was regenerated.
