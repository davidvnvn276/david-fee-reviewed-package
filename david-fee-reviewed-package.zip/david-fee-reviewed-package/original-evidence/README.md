# DAVID: Rayls fee collection and conversion gates

This directory preserves the original investigation. Its English walkthrough is
`david-fee-guide.md`. The current reviewed manuscript and claim map are in the
package root; `david-rayls-fee-article.md` preserves the original English draft.
Raw observations, source and calldata retain their original bytes. Explanatory
documents have been localized or updated, and this directory's manifest has
been regenerated for the English edition. The recorded primary
snapshot is Rayls mainnet (chain ID 72957), block **11,848,988**, timestamp
**2026-10-05 10:43:21 UTC**. The first three sampled transaction blocks are 11,847,978,
11,848,013 and 11,848,024: one account's claim/approval/delegation sequence.
Three further Explorer-labelled setPrice calls from a second account were checked
on October 7 at blocks 12,018,215, 12,018,442 and 12,018,680.
All twelve balance differences matched receipt-derived fee components exactly.
These are selected observations, not representative network statistics.

## What is included

- `raw/`: Original RPC requests/responses, Explorer metadata, verified ABI and
  source metadata, plus unsuccessful archive/proof requests. JSON pretty printing
  preserves the values but is not a byte-for-byte copy of HTTP transport bodies.
- `fee-reconciliation.csv`: All six receipt fees and before/after balance differences in
  integer native units and exact decimal USDr.
- `facts.json`: Snapshot and fee data used by the article and graphics.
- `gate-tests.json`: Seven eth_call outcomes, including one explicitly
  counterfactual balance-override test.
- `verified-FeeAggregator.sol`: The Explorer-published implementation source,
  preserving its original license notice. This is not assumed to be the newest
  GitHub source or a production deployment we created ourselves.
- `verify_saved.py`: Offline consistency checks against the original data.
- `reproduce.py`: Fresh state reads and optional read-only gate simulations.
- `templates/`: ABI-derived calldata and error selectors for the reviewed
  implementation. The script verifies the implementation pointer and bytecode
  match before interpreting the state.
- `repeat-state-20261007/`: Fresh state reads and seven simulations at block
  12,018,889 (2026-10-07 07:47:08 UTC), including the bytecode match and keeper-role check.
- `repeat-fees-20261007/`: Three newer single-transaction-block fee reconciliations,
  their raw RPC requests/responses, and Explorer method labels.
- `historical-recheck-20261007/`: Failed attempts to re-read the October 5 balances;
  the RPC returned pruned-state errors, preserved as unavailable observations.
- `live-validation/`: A separate fresh run of the delivered script. Its block
  and balance can differ from the article snapshot.
- `render_evidence.py`: Optional redraw of the two graphics; requires Matplotlib.
  This dependency is not needed for the audit or offline checks.
- `SHA256SUMS.txt`: Hashes for the delivered files. This preserves file identity;
  it is not an onchain authentication certificate.

## Run

Python 3 is sufficient; no third-party Python packages are needed.

```bash
python verify_saved.py
python reproduce.py --simulate --override
```

On Windows, `py -3` can be used instead of `python` if the Python Launcher is
installed. The live script was exercised in Linux, not on the user's Windows PC.

An optional historical recheck can use:

```bash
python reproduce.py --block 11848988 --simulate --override
```

By October 7 the October 5 balance states were pruned on this public endpoint.
A later reviewer batch also returned null for the three October 5 receipts.
The original responses remain preserved for offline arithmetic checks. Null
receipts are unavailable observations, not evidence that a transaction did not exist.
Historical state may be pruned. A pruning error must remain an unavailable
observation, not be interpreted as a zero balance or counter. The default live
run pins a fresh block and creates a new output directory without overwriting
the original evidence.

The script only calls allowlisted read-only RPC methods. Providing a `from`
address to eth_call sets the simulated caller; it does not prove possession of
its key. State overrides are temporary inputs to a simulation, not deposits.
The package contains no keys, signatures, funded test wallets or transaction
submission commands.

## Evidence boundaries

The six sampled balance differences, receipt fields, configured limits and
counter values are recorded node responses. The runtime bytecode also matches
Explorer's published bytes. These checks do not independently authenticate a
consensus certificate, prove a complete upgrade history, or establish every
historical Rayls fee/burn route.

The attempts to read older state at blocks 5,000,000, 8,000,000 and 10,000,000
returned pruning errors. Two eth_getProof attempts were rejected because the
target was outside the provider's allowed proof window. No successful Merkle
proof is claimed or included.

The Ethereum burn-address data explored during topic selection is not used to
attribute any aggregate burn to this Public Chain contract. The inspected proxy's
zero counters must not be presented as proof that Rayls has never burned RLS.

## Primary sources

- https://docs.rayls.com/docs/public-chain-reference
- https://docs.rayls.com/docs/public-chain-tokenomics
- https://docs.rayls.com/docs/about-the-axyl-consensus-algorithm
- https://explorer.rayls.com/address/0x07e17e17e17e17e17e17e17e17e17e17e17e17e3
- https://explorer.rayls.com/address/0x07e17e17e17e17e17e17e17e17e17e17e17e17e4?tab=contract
- https://mainnet-rpc.rayls.com/

The collected implementation runtime Keccak-256 is
`0xaad3dba456f6b9e9613677cccc218b81db1e58c5d41f50f0abae8ff748d7f20a`.
The raw JSON also preserves the code bytes, so matching them does not require
trusting this precomputed hash.

## Published-analysis scope

The manuscript compares two main configuration captures (October 5 and October 7);
the shorter October 5 follow-up is also retained. Both principal captures returned
the same allocation, limits, zero pool, zero counters and seven simulation outcomes.
This does not establish continuous conditions at every intervening block.
The figures use all six fee observations and the October 7 gate snapshot.
No user video, transaction submission, successful swap, Ethereum delivery or
completed burn is claimed.
