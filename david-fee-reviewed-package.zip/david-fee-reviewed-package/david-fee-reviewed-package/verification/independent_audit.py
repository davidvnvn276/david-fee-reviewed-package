import json, hashlib, sys, datetime, urllib.request
from pathlib import Path
from decimal import Decimal
sys.path.insert(0, str(Path(__file__).parent/'audit-dependencies'))
from Crypto.Hash import keccak

BASE=Path(__file__).parent
P=BASE.parent/'original-evidence'
OUT=BASE/'independent-comparison'
OUT.mkdir(exist_ok=True)
PROXY='0x07e17e17e17e17e17e17e17e17e17e17e17e17e3'
RPC='https://mainnet-rpc.rayls.com/'
def j(p): return json.loads(p.read_text())
def k(s):
 h=keccak.new(digest_bits=256);h.update(s);return h.hexdigest()
assert k(b'')=='c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470'
def label(qp,rp,np):
 q=j(qp);r={x['id']:x for x in j(rp)};ns=j(np)
 assert len(q)==len(ns)
 return {n:(qq,r[qq['id']]) for n,qq in zip(ns,q)}
old=label(P/'raw/historical-and-fee-requests.json',P/'raw/historical-and-fee-results.json',P/'raw/historical-and-fee-names.json')
oa=label(P/'raw/author-balance-request.json',P/'raw/author-balance-result.json',P/'raw/author-balance-names.json')
new=label(P/'repeat-fees-20261007/01-request.json',P/'repeat-fees-20261007/01-response.json',P/'repeat-fees-20261007/01-labels.json')
na=label(P/'repeat-fees-20261007/02-request.json',P/'repeat-fees-20261007/02-response.json',P/'repeat-fees-20261007/02-labels.json')
facts=j(P/'facts.json');checks=[];live=[]
def check(name, condition):
 assert condition,name
 checks.append(name)
def balance(pair,address,block):
 q,r=pair
 check('balance_request_binding',q['method']=='eth_getBalance' and q['params'][0].lower()==address.lower() and int(q['params'][1],16)==block)
 return int(r['result'],16)
for row in sorted(facts['fees'],key=lambda x:x['block']):
 n=row['block'];txh=row['tx_hash']
 if n<12000000:
  bq,b=old[f'fee_{n}_block'];rq,r=old['receipt_'+txh]
  cp=[old[f'fee_{n}_before'],old[f'fee_{n}_after']];ap=[oa[f'{n}_before'],oa[f'{n}_after']]
 else:
  bq,b=new[f'{n}_block'];rq,r=new[f'{n}_receipt']
  cp=[new[f'{n}_collector_before'],new[f'{n}_collector_after']];ap=[na[f'{n}_author_before'],na[f'{n}_author_after']]
 b=b['result'];r=r['result']
 check('block_request_binding',bq['method']=='eth_getBlockByNumber' and int(bq['params'][0],16)==n)
 check('receipt_request_binding',rq['method']=='eth_getTransactionReceipt' and rq['params'][0]==txh)
 check('single_transaction_and_receipt',len(b['transactions'])==1 and b['transactions'][0]['hash']==r['transactionHash']==txh and r['status']=='0x1')
 check('block_hash_binding',b['hash']==r['blockHash']==row['block_hash'])
 check('sender_and_author_binding',b['transactions'][0]['from'].lower()==row['sender'].lower() and b['miner'].lower()==row['block_author'].lower())
 gas=int(r['gasUsed'],16);base=int(b['baseFeePerGas'],16);price=int(r['effectiveGasPrice'],16)
 c=balance(cp[1],PROXY,n)-balance(cp[0],PROXY,n-1)
 a=balance(ap[1],b['miner'],n)-balance(ap[0],b['miner'],n-1)
 check('base_priority_total',c==gas*base and a==gas*(price-base) and c+a==gas*price)
 check('fact_integers',gas==row['gas_used'] and c==int(row['collector_delta_raw']) and a==int(row['author_delta_raw']) and c+a==int(row['receipt_fee_raw']))
 exact=lambda raw:format(Decimal(raw)/Decimal(10**18),'f')
 check('fact_decimals',exact(c)==row['collector_delta_usdr'] and exact(a)==row['author_delta_usdr'] and exact(c+a)==row['receipt_fee_usdr'])
 check('fact_percentage',Decimal(100)*Decimal(c)/Decimal(c+a)==Decimal(row['aggregator_share_percent']))
 for name,method,params in [('block','eth_getBlockByNumber',[hex(n),True]),('receipt','eth_getTransactionReceipt',[txh]),('collector_before','eth_getBalance',[PROXY,hex(n-1)]),('collector_after','eth_getBalance',[PROXY,hex(n)]),('author_before','eth_getBalance',[b['miner'],hex(n-1)]),('author_after','eth_getBalance',[b['miner'],hex(n)])]:
  live.append((str(n)+'_'+name,method,params))

meta=j(P/'raw/aggregator-impl.json');abi=meta['abi']
def abi_type(x):
 t=x['type']
 return '('+','.join(abi_type(a) for a in x['components'])+')'+t[5:] if t.startswith('tuple') else t
selectors={}
for x in abi:
 if x['type'] in ('function','error'):
  sig=x['name']+'('+','.join(abi_type(a) for a in x.get('inputs',[]))+')'
  selectors[x['name']]='0x'+k(sig.encode())[:8]
check('verified_source_file',meta['source_code']==(P/'verified-FeeAggregator.sol').read_text() and meta['is_verified'])
for c in j(P/'templates/call-queries.json'):
 name=c['name'].split('_')[0] if c['name'].startswith(('RLS_','USDr_')) else c['name']
 if c['name'].endswith('balanceOf'):name='balanceOf'
 if c['name'].endswith('decimals'):name='decimals'
 if name in selectors:check('calldata_selector_'+name,c['data'][:10]==selectors[name])
sim=j(P/'templates/simulation-queries.json')
amounts={'zero':0,'ten':10,'minimum':1000,'over_maximum':100001,'unauthorized_minimum':1000,'funded_override':1000}
for c in sim['cases']:
 data=c['call']['data']
 if c['name']=='empty_distribution':check('distribution_calldata',data==selectors['distributeEpochFees']);continue
 check('swap_calldata',data[:10]==selectors['swapToRls'])
 w=[int(data[i:i+64],16) for i in range(10,len(data),64)]
 check('swap_amount_and_asset',w==[0x400,amounts[c['name']]*10**18,0])
 if c['name']=='funded_override':check('counterfactual_override',int(c['override'][PROXY]['balance'],16)==2000*10**18)
check('keeper_role_hash','0x'+k(b'KEEPER_ROLE')==sim['extra'][0]['params'][0]['data'][10:74].join(['0x','']))
for x in j(P/'templates/errors.json'):check('error_selector_'+x['name'],x['selector']==selectors[x['name']])
checksums=[]
for line in (P/'SHA256SUMS.txt').read_text().splitlines():
 h,name=line.split(maxsplit=1);f=P/name.strip()
 check('checksum_'+name.strip(),f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()==h)
 checksums.append(name.strip())

# A separate HTTP batch rechecks headers, receipts and available historical balances.
queries=[{'jsonrpc':'2.0','id':i,'method':m,'params':p} for i,(_,m,p) in enumerate(live,1)]
(OUT/'request.json').write_text(json.dumps(queries,indent=2))
if (OUT/'response.json').exists():
 answers=j(OUT/'response.json')
else:
 req=urllib.request.Request(RPC,data=json.dumps(queries).encode(),headers={'Content-Type':'application/json','User-Agent':'Mozilla/5.0'})
 with urllib.request.urlopen(req,timeout=45) as response:answers=json.loads(response.read())
 (OUT/'response.json').write_text(json.dumps(answers,indent=2))
by={x['id']:x for x in answers};live_status=[]
for i,(name,_,_) in enumerate(live,1):
 item=by[i];n,kind=name.split('_',1);row=next(r for r in facts['fees'] if r['block']==int(n))
 if 'error' in item or item.get('result') is None:live_status.append({'label':name,'available':False,'error':item.get('error',{'message':'RPC returned null; unavailable, not zero'})});continue
 result=item['result']
 if kind=='block':check('live_header_'+n,result['hash']==row['block_hash'] and len(result['transactions'])==1)
 if kind=='receipt':check('live_receipt_'+n,result['transactionHash']==row['tx_hash'] and result['blockHash']==row['block_hash'] and int(result['gasUsed'],16)==row['gas_used'] and int(result['effectiveGasPrice'],16)==int(row['effective_price_raw_per_gas']))
 live_status.append({'label':name,'available':True,'result':result if kind not in ('block','receipt') else 'hash and fee fields match'})
for row in facts['fees']:
 n=str(row['block']);records={x['label']:x for x in live_status}
 for kind,expected in [('collector',int(row['collector_delta_raw'])),('author',int(row['author_delta_raw']))]:
  before=records[n+'_'+kind+'_before'];after=records[n+'_'+kind+'_after']
  if before['available'] and after['available']:check('live_delta_'+n+'_'+kind,int(after['result'],16)-int(before['result'],16)==expected)

pin=j(BASE/'independent-pinned-12018889/summary.json')
orig=j(P/'repeat-state-20261007/summary.json')
for field in ['block','block_hash','timestamp','native_usdr_raw','erc20_usdr_raw','usdr_balance','usdr_views_equal','usdr_decimals','config_basis_points','swap_count','distributed_rls_raw','limits_normalized_usd6','pool','pending_raw','runtime_bytecode_matches_explorer','runtime_sha256']:
 check('same_block_'+field,pin[field]==orig[field])
check('same_block_all_simulations',[(s['case'],s['outcome']) for s in pin['simulations']]==[(s['case'],s['outcome']) for s in orig['simulations']])
fresh=j(BASE/'fresh-independent/summary.json')
summary={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks_passed':len(checks),'six_fee_rows_verified':True,'twelve_saved_balance_deltas_verified':True,'checksums_passed':len(checksums),'same_block_independent_repeat':pin,'fresh_independent_repeat':fresh,'live_rechecks':live_status,'checks':checks,'scope':'Provider RPC observations and internally consistent saved responses; no independent consensus-certificate authentication or completed burn claim.'}
(OUT/'audit.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'checks_passed':len(checks),'checksums':len(checksums),'live_available':sum(x['available'] for x in live_status),'live_unavailable':sum(not x['available'] for x in live_status),'pinned_block':pin['block'],'fresh_block':fresh['block']},indent=2))
