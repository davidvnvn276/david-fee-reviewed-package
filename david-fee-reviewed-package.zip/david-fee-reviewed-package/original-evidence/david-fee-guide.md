# DAVID: guide to the fee article, evidence and graphics

## What the article establishes

The article asks a question someone outside the community can search for:
**Do blockchain transaction fees automatically burn tokens?** Rayls supplies a
concrete case because transaction gas is paid in USDr, whereas its documented
reward-and-burn route uses RLS.

The investigation reconciles six existing transactions across two dates, reads
the deployed Fees Aggregator at two principal blocks and tests its conversion
gates through seven read-only cases. It does not report transactions submitted
by the author or a final Ethereum burn.

Use `../david-fee-article-reviewed.md` as the current manuscript. The
`david-rayls-fee-article.md` in this directory preserves the original English
manuscript for comparison. Use `../claim-audit-reviewed.csv` as the current
six-sample claim map.

## Facts to preserve when publishing

| Finding | Value and scope |
|---|---|
| Network | Rayls mainnet, chain ID 72957 |
| Inspected proxy | `0x07e17e17e17e17e17e17e17e17e17e17e17e17e3` |
| Primary captures | 11,848,988 on October 5 and 12,018,889 on October 7 |
| Primary USDr balances | 691.782528048 and 697.144028784 |
| Sampled transactions | Three October 5 claim/approval/delegation calls, then three October 7 Explorer-labelled `setPrice` calls |
| Exact reconciliation | Twelve Aggregator/author balance differences match the receipt-derived components |
| Aggregator share of each sample's total fee | Approximately 83.33% in the first group and 16.15% in the second |
| Captured allocation | 5,000 / 0 / 5,000 basis points: validator / ecosystem / burn |
| Nominal normalized limits | 1,000 to 100,000 USDr |
| Captured pool and counters | Zero USDr pool, zero recorded swaps and distributed RLS, empty pending buckets |
| Counterfactual result | A simulated 2,000-USDr balance and 1,000-USDr swap return `PoolNotConfigured` |
| Empty distribution | Simulated return `0`, not a completed transaction |

The sample percentages arise from the effective gas prices. They are not
representative network statistics or fixed rates associated with method names.
The 50% burn allocation concerns RLS obtained later; it is not a completed burn
of half of each user's total USDr gas payment.

The implementation normalizes swap amounts to six decimal places. The stated
limits are nominal values; do not convert them into a stronger exact fractional
bound than the implementation enforces.

## Verify the saved evidence

From this directory:

```bash
python verify_saved.py
```

Python's standard library is sufficient. For the complete package's file
inventories and the additional reviewer audit, use the root README commands.
An offline pass establishes arithmetic and internal consistency, not independent
authentication of an Axyl consensus certificate.

## Obtain a fresh read-only capture

From this directory:

```bash
python reproduce.py --simulate --override
```

The script pins a current block, verifies chain ID and implementation bytes,
reads configuration and balances, and optionally simulates the gate tests. The
new output directory is printed at completion. It never overwrites the bundled
observations. Fresh state may differ from the published captures; record the
actual result rather than forcing a match.

To request the article's repeat block explicitly:

```bash
python reproduce.py --block 12018889 --simulate --override
```

Historical state and receipts may be unavailable from the public endpoint.
By October 7 the October 5 balance states were pruned. A later reviewer batch
returned null for the three October 5 receipts. Errors and null results are
unavailable observations, not zeros and not evidence that the recorded
transactions did not exist. Preserved responses can still be checked offline;
a fresh historical balance check requires an appropriate archive provider.

On Windows with the Python Launcher installed, these commands can use `py -3`:

```powershell
py -3 .\verify_saved.py
py -3 .\reproduce.py --simulate --override
```

The live script was exercised on Linux. This package does not claim testing on
the user's Windows computer. Docker, WSL, a funded wallet and gas payment are not
required for these read-only commands.

## Interpret the simulations correctly

The `from` address in `eth_call` sets the simulated caller. Its keeper-role
membership was checked at the recorded blocks, but that is not proof that the
author owns the address or its key.

The 2,000-USDr balance override is an explicitly counterfactual simulation input.
No 2,000-USDr deposit occurred. No persistent state changed. Its result only
shows that sufficient balance would still encounter the pool check in the
captured configuration.

`swapToRls()` and `distributeEpochFees()` are separate keeper functions. The
latter consumes pending RLS; it does not itself exchange accumulated USDr. A
simulated return of `0` from empty pending buckets is not evidence of a completed
distribution.

## Select and place the graphics

Use `../image-guide.md` for the current PNG/SVG files and insertion points. The
new tables preserve exact numeric values and results; the earlier cover and
explanatory figures are also included. Dates and account watermarks are omitted
from the graphics, while block numbers retain the scope of each observation.

The two original investigation graphics in this directory remain preserved.
They are not the preferred current publishing assets. Optional regeneration
with `render_evidence.py` requires Matplotlib; neither verification nor fresh
read-only reproduction requires that graphics dependency.

Before publishing, read every word at full resolution, keep the supplied Rayls
mark unchanged and avoid a caption implying that a configured burn allocation
is an executed canonical burn. If the article editor handles Markdown tables
poorly, use the table images while retaining a concise numeric explanation in
the article text.

## Optional short evidence walkthrough

A screen recording can show the commands and output, but no user recording is
included or claimed. Speak only about the results actually visible in the run.
A two- to three-minute explanation could cover:

1. “I checked saved mainnet observations, not transactions I submitted. The six
   sampled blocks span two dates, and all twelve balance differences reconcile
   to base and priority fees.”
2. “The two percentages describe these samples. They are not permanent network
   rates and do not mean half of each total gas payment was already burned.”
3. “A fresh read-only run pins its own block and verifies the proxy implementation.
   Its state can differ from the published captures.”
4. “The balance override is simulated, not a deposit. The `from` field sets a
   caller for `eth_call`; it does not prove possession of a private key.”
5. “Collecting USDr, converting to RLS and destroying canonical Ethereum tokens
   need separate evidence. This package does not establish the final burn.”

## Evidence link and publication checklist

The public repository is
[davidvnvn276/david-fee-reviewed-package](https://github.com/davidvnvn276/david-fee-reviewed-package).
Replace the previous ZIP with the complete English edition before pointing
reviewers to it. Use the root manuscript's evidence paragraph or adapt its
wording while keeping the reproduction and scope qualifications.

- Keep exact balances, blocks, raw integer results and case names unchanged.
- Distinguish fresh captures from replay of saved reviewer responses.
- Keep the six-sample scope and historical-data limitations visible.
- Do not infer who controls the sampled accounts.
- Do not describe zero proxy counters as proof that Rayls has never burned RLS.
- Do not claim a successful swap, distribution, bridge delivery or Ethereum burn
  that the package has not established.
- Check both package manifests before uploading the ZIP.

The translated guide improves accessibility; it does not turn missing
transaction-level evidence into a verified execution or guarantee a quest score.
