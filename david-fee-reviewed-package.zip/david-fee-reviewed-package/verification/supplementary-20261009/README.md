# Supplementary captured state: October 9, 2026

These files preserve an additional read-only capture that was already recorded
before the English package was assembled. They do not replace the article's
October 5 and October 7 primary captures.

| Field | Recorded value |
|---|---|
| Chain | Rayls mainnet, chain ID 72957 |
| Block | 12,167,402 |
| Block hash | `0x3fd85c8a19a5ec035011360bb0841ed64a0806e44d212080e89deaffe5bc0381` |
| Block timestamp | October 9, 2026, 14:34:00 UTC |
| Capture timestamp | October 9, 2026, 14:34:25.323346 UTC |
| Native / ERC-20 USDr balance | 704.728012176, equal raw values |
| Allocation basis points | 5,000 validator / 0 ecosystem / 5,000 burn |
| Normalized six-decimal limits | 1,000,000,000 and 100,000,000,000; nominally 1,000 and 100,000 USDr |
| Configured USDr pool | Zero address |
| Recorded swaps / distributed RLS / pending buckets | Zero |
| Runtime SHA-256 | `9e992038bbc77e73a6bac80d90ac9b839c7d73d3f0cb83e638951f90d31515b3` |

The seven recorded simulation outcomes are `ZeroAmount`, `BelowMinimumSwap`,
`InsufficientBalance`, `ExceedsMaximumSwap`,
`AccessControlUnauthorizedAccount`, empty-distribution return `0` and
`PoolNotConfigured` after the explicitly counterfactual 2,000-USDr balance
override. No deposit or persistent state change occurred.

The numbered request/response/label files preserve the three RPC batches.
`block.json`, `capture.json`, `explorer-implementation.json` and `summary.json`
preserve the header, capture metadata, Explorer implementation data and decoded
results. JSON values are preserved; these files are not signed provider
attestations or independently authenticated consensus certificates.

The package manifest checks their file identity. The original verification
script and main reviewer audit cover their documented primary inputs; they do
not claim to validate this supplementary capture. No continuous-state claim or
final Ethereum burn is inferred from this additional point.
