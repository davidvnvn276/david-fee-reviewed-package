# Do Blockchain Transaction Fees Automatically Burn Tokens? A Rayls Onchain Check

Not necessarily. A gas payment proves that a transaction incurred a fee. Whether that payment leads to a token burn depends on the chain’s mechanism and the subsequent execution steps.

Rayls offers a useful case because gas is paid in **USDr**, while its documented reward-and-burn process uses **RLS**. I reconciled six existing mainnet transactions across two dates, checked the fee-collection contract, and repeated its state reads and simulations nearly two days apart.

The most useful finding was that **the Aggregator received about 83.33% of the total gas fee in one sample group, but only 16.15% in the other**. Both groups reconciled exactly. The captured USDr-to-RLS route also had two unmet prerequisites, despite a configured 50% burn allocation.

## What does Rayls say happens to transaction fees?

The [Public Chain tokenomics documentation](https://docs.rayls.com/docs/public-chain-tokenomics) describes accumulated USDr being exchanged for RLS, with half of the resulting RLS allocated to validators and half sent to Ethereum for a later batch burn.

That introduces several distinct stages: collecting USDr, acquiring RLS, allocating it, delivering the burn share across chains, and destroying tokens on Ethereum. Each needs its own evidence.

There is also a detail to reconcile between official sources. The tokenomics overview describes transaction fees being redirected to the Fees Aggregator. The [Axyl technical specification](https://docs.rayls.com/docs/about-the-axyl-consensus-algorithm) is more precise: base fees are collected by the Aggregator, while priority fees are credited to the batch author’s coinbase address.

The difference matters when deciding which part of a gas payment is collected directly for that conversion route.

## Where did the sampled gas payments actually go?

The first group was a reward claim, an approval and a delegation from one account on **5 October 2026**, at blocks **11,847,978; 11,848,013; and 11,848,024**.

The second group was three calls Explorer labelled `setPrice`, from a different account on **7 October**, at blocks **12,018,215; 12,018,442; and 12,018,680**. I have not inferred who controlled either account.

Each selected block contained exactly one transaction. For each, I read the receipt and compared the Aggregator’s and block author’s USDr balances at the parent block and transaction block. These were existing transactions, not transactions I submitted.

An effective gas price combines the base fee with a priority fee, or tip. Two examples show the difference; all six exact results are preserved in the evidence data:

| Sample | Gas paid, USDr | Aggregator increase, USDr | Block-author increase, USDr |
|---|---:|---:|---:|
| Approval, block 11,848,013 | 0.0029593728 | 0.002466144 | 0.0004932288 |
| `setPrice`, block 12,018,215 | 0.011294024437798275 | 0.001824048 | 0.009469976437798275 |

All **12 balance differences** matched the expected components exactly, in the smallest native unit:

**Aggregator credit = gas used × block base fee**

**Author credit = gas used × (effective gas price − block base fee)**

The approval used 51,378 gas; the `setPrice` example used 38,001. Both blocks had a base fee of **48,000,000,000 native units per gas**, but their effective gas prices were **57,600,000,000** and **297,203,348,275**, respectively. USDr has 18 decimals.

Dividing each Aggregator credit by its total gas fee gives **83.33%** for every sample in the first group and **16.15%** for every sample in the second, rounded to two decimals. The remaining amounts reconcile to the authors’ priority-fee credits.

The variation follows the sampled effective gas prices. It is not evidence that a method name determines the split, nor a network-wide average. It demonstrates why total gas paid is an inadequate stand-in for the amount entering this conversion route. The documented 50% allocation applies to RLS obtained later, not an already completed burn of half of each user’s total USDr gas payment.

## Was the next step ready to execute?

The inspected Fees Aggregator proxy was:

`0x07e17e17e17e17e17e17e17e17e17e17e17e17e3`

Both reviews used Rayls mainnet, **chain ID 72957**. I read the proxy’s EIP-1967 implementation slot and compared that implementation’s RPC runtime bytecode with Explorer’s published deployed bytecode. The bytes matched at both captures, so the analysis uses the deployed implementation’s verified ABI and source.

| Pinned state | Aggregator USDr balance |
|---|---:|
| 5 Oct 2026, 10:43:21 UTC; block 11,848,988 | 691.782528048 |
| 7 Oct 2026, 07:47:08 UTC; block 12,018,889 | 697.144028784 |

At each capture, native `eth_getBalance` and USDr’s ERC-20 `balanceOf` returned the same raw balance. Rayls’ network reference explains that USDr exposes both interfaces through a custom precompile.

Both captures also returned:

- **50% validator / 0% ecosystem / 50% burn** allocation, from 5,000 / 0 / 5,000 basis points.
- **1,000–100,000 USDr** nominal swap limits, decoded using the implementation’s six-decimal normalization.
- A **zero pool address** for USDr’s configured swap route.
- **Zero** recorded swaps, distributed RLS and pending-distribution buckets.

These readings identify two separate prerequisites: sufficient balance for the minimum swap, and a configured pool. An allocation setting establishes how RLS is intended to be split; it does not establish that the conversion has happened.

## What did read-only execution reveal?

I tested `swapToRls()` with `eth_call` at both pinned blocks. This executes a simulated call without signing a transaction or changing persistent chain state.

The simulated authorized caller was an address whose `KEEPER_ROLE` membership was checked onchain. Setting a caller in `eth_call` does not prove possession of that address’s key.

| Simulation on the captured state | Result at both blocks |
|---|---|
| Swap 0 USDr | `ZeroAmount` |
| Swap 10 USDr | `BelowMinimumSwap` |
| Swap 1,000 USDr | `InsufficientBalance` |
| Swap 100,001 USDr | `ExceedsMaximumSwap` |
| Swap 1,000 USDr from an address without the keeper role | `AccessControlUnauthorizedAccount` |

To isolate the next check, a separate simulation temporarily overrode the Aggregator’s balance to **2,000 USDr**, then attempted a 1,000-USDr swap. Both captures returned **`PoolNotConfigured`**.

**No 2,000-USDr deposit occurred.** This was a counterfactual input to the simulation. Its narrow finding is that sufficient balance alone would not make this route pass the pool check under either captured configuration.

The outcomes agree with the verified implementation’s sequence: after access and pause checks, it checks the amount, supported token, normalized limits and balance before reaching the pool-dependent swap.

There is another useful distinction in that implementation: **`swapToRls()` and `distributeEpochFees()` are separate keeper functions.** The distribution function consumes pending RLS; it does not itself convert an accumulated USDr balance. Simulating it against the empty pending buckets returned **0** at both blocks. This records a simulated return, not a completed distribution transaction.

## What would prove that tokens were actually burned?

For this fee route, verification would need to connect a successful USDr-to-RLS swap to the received RLS, its allocation, delivery of the burn share to Ethereum, and the final token destruction there. A configured percentage or bridge-send event establishes an earlier stage.

The scope of the findings matters. The six sampled blocks establish fee collection and the variable share of total gas fees entering the Aggregator in those samples. The state reads and simulations establish this proxy’s configuration and conversion gates at two timestamps. They do not establish a completed burn, uninterrupted conditions between the captures, or the history of every Rayls fee mechanism.

In particular, this proxy’s zero counters are not proof that Rayls has never burned RLS. The documentation also describes other inflows and delayed Ethereum burn batches. Attributing those burns to this Public Chain route requires a transaction-level connection.

## How can someone check the findings again?

The investigation preserves the raw RPC requests and responses, block hashes, verified implementation metadata, calculations and simulation inputs. A fresh check should pin a block, verify the chain and implementation, then read the balances, limits, allocation, pool configuration and counters before interpreting a simulated result.

Historical-data availability is a practical limit. By 7 October, the public RPC had pruned the sampled 5 October balance states. A subsequent independent recheck also returned null for those three transaction receipts, although all six sampled block headers remained available and matched the saved block hashes. The 5 October reconciliation therefore relies on the preserved original responses. A fresh recheck needs a provider retaining the historical receipts and archive balance state; newly sampled blocks can be checked while their data remain available. Pruning errors and null receipts remain unavailable observations, not zero balances or proof that a transaction did not exist. The saved-response checks verify arithmetic and bytecode consistency; they do not independently authenticate an Axyl consensus certificate.


The [public evidence repository](https://github.com/davidvnvn276/david-fee-reviewed-package) contains the accompanying package of raw requests and responses, all six fee reconciliations, the verified implementation source, and scripts for offline checks and fresh read-only reproduction. Download the complete English ZIP, extract it, and from its package root run:

```bash
python verify_package.py
python original-evidence/verify_saved.py
python original-evidence/reproduce.py --simulate --override
```

The package checker verifies file identity; the saved-evidence script checks internal consistency. The reproduction script pins a fresh mainnet block, so its state and outcomes may differ from the published captures. The override is a temporary simulation input; none of these commands signs or submits a transaction.

The same method is useful beyond Rayls: identify the fee asset, locate its collection path, and require evidence for every subsequent conversion and burn step. A transaction fee and a token burn can be connected, but the connection should be demonstrated.

**Sources and onchain references**

- [Rayls Public Chain tokenomics](https://docs.rayls.com/docs/public-chain-tokenomics)
- [Axyl technical specification](https://docs.rayls.com/docs/about-the-axyl-consensus-algorithm)
- [Rayls network, RPC and token reference](https://docs.rayls.com/docs/public-chain-reference)
- [Fees Aggregator proxy](https://explorer.rayls.com/address/0x07e17e17e17e17e17e17e17e17e17e17e17e17e3)
- [Verified implementation](https://explorer.rayls.com/address/0x07e17e17e17e17e17e17e17e17e17e17e17e17e4?tab=contract)
- [Reward-claim transaction](https://explorer.rayls.com/tx/0x6c948f0d88e7b07359cc40a5372082d110cb5ed7a0b52b60a0926cdab79efcba)
- [Approval transaction](https://explorer.rayls.com/tx/0x71b1909e71faf4b28ba85beb2ad2e9bf06bcf1734e0bb96af6231e0c364656eb)
- [Delegation transaction](https://explorer.rayls.com/tx/0xba34fbc04d10b4fb9da12b92a2c41c292a9b990d78be4c9511418ee2502d7f73)
- [7 October sample: block 12,018,215](https://explorer.rayls.com/tx/0x7a9e9ebfc851ed4c99d121b78e1897cb54cebf74092bda7538b8d0fbb4043351)
- [7 October sample: block 12,018,442](https://explorer.rayls.com/tx/0x2871a106aad0f4d3f790812537061f5bcdea7e544d4c0f0e1e63e737d8a876bd)
- [7 October sample: block 12,018,680](https://explorer.rayls.com/tx/0x240984797637292c5d33292a6fefff802ce5023af99fcb0e127584f82117b5c4)

@Rayls
